<?php
    // PRODUCTION
    $apiKey = '<Your-API-Key>'; // PRODUCTION KEY
    $currentSecret= '<Your-Secret-Key>'; // PRODUCTION SECRET
/*
****************************************************************************
* IMPORTANT: Verify that the correct screen-set collection name is defined *
* in gigyaPlugins.js, customize.php, and customize_processor.php for the   *
* 'siteScreenSet' parameter!!                                              *
****************************************************************************
*/
?>
